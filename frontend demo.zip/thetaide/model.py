"""Portable demo records. This module does not import the training backend."""
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import random
from uuid import uuid4


@dataclass
class Config:
    name: str = "cartpole_ppo_baseline"
    env: str = "cartpole"
    seed: int = 42
    total_timesteps: int = 10000
    lr: float = 0.0003
    batch_size: int = 64
    gamma: float = 0.99

    def yaml(self):
        # Match the existing Offline-BlendRL Hydra groups and PPO field names.
        return (
            "# ThetaIDE • Offline-BlendRL configuration preview\n"
            "# Export to in/config/experiment/; simulation does not execute this.\n"
            "# @package _global_\n\n"
            "defaults:\n  - override /agent: ppo/dnn\n"
            f"  - override /env: {self.env}\n  - override /mode: online\n\n"
            f"experiment_id: {json.dumps(self.name)}\n"
            f"seed: {self.seed}\ntotal_timesteps: {self.total_timesteps}\n"
            "eval_episodes: 10\nno_offline: true\n\n"
            f"agent:\n  lr: {self.lr}\n  batch_size: {self.batch_size}\n"
            f"  gamma: {self.gamma}\n"
        )


def sample(config, index):
    rng = random.Random(config.seed * 101 + index)
    progress = index / 60
    reward = max(0, min(500, 20 + 475 * (1 - math.exp(-3.6 * progress)) + rng.uniform(-18, 18)))
    return {"step": round(config.total_timesteps * progress),
            "reward": round(reward, 2),
            "loss": round(0.8 * math.exp(-4 * progress) + rng.uniform(0.015, 0.055), 4)}


def new_run(config):
    return {"id": uuid4().hex[:10], "created": datetime.now(timezone.utc).isoformat(),
            "config": asdict(config), "status": "running", "simulated": True,
            "metrics": [], "notes": ""}


class Store:
    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def save(self, run):
        folder = self.root / run["id"]
        folder.mkdir(exist_ok=True)
        temporary = folder / "record.tmp"
        temporary.write_text(json.dumps(run, indent=2), encoding="utf-8")
        temporary.replace(folder / "record.json")
        (folder / "config.yaml").write_text(Config(**run["config"]).yaml(), encoding="utf-8")
        rows = ["step,reward,loss"] + [f'{m["step"]},{m["reward"]},{m["loss"]}' for m in run["metrics"]]
        (folder / "metrics.csv").write_text("\n".join(rows) + "\n", encoding="utf-8")

    def load(self):
        runs, errors = [], []
        for path in self.root.glob("*/record.json"):
            try:
                run = json.loads(path.read_text(encoding="utf-8"))
                Config(**run["config"])
                if run["id"] != path.parent.name or not isinstance(run["metrics"], list):
                    raise ValueError("Invalid run record")
                for key in ("status", "notes", "created", "simulated"):
                    run[key]
                if run["status"] == "running":
                    run["status"] = "interrupted"
                runs.append(run)
            except (OSError, ValueError, TypeError, KeyError) as exc:
                errors.append(f"Could not load {path}: {exc}")
        return sorted(runs, key=lambda r: r["created"], reverse=True), errors


def example_runs():
    runs = []
    for seed, name in ((42, "cartpole_ppo_baseline"), (7, "cartpole_seed_study")):
        config = Config(name=name, seed=seed)
        run = new_run(config)
        run.update(id=f"example-{seed}", status="example", metrics=[sample(config, i) for i in range(1, 61)],
                   notes="## Hypothesis\nA small learning rate should produce stable improvement.\n\n"
                         "## Next iteration\nCompare a second seed before changing the policy.\n\n"
                         "These are synthetic example metrics, not training results.")
        runs.append(run)
    return runs
