"""Spyder-inspired research workspace, with an explicitly simulated executor."""
import argparse
from dataclasses import asdict
from pathlib import Path
import sys

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QAction, QFont
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
    QDockWidget, QTabWidget, QPlainTextEdit, QLineEdit, QComboBox, QSpinBox,
    QDoubleSpinBox, QPushButton, QTreeWidget, QTreeWidgetItem, QToolBar,
    QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView,
    QProgressBar, QScrollArea, QFileDialog, QMessageBox, QDialog,
)
from .model import Config, Store, example_runs, new_run, sample
from .theme import STYLE, ThemeManager, theme_color
from .theme_builder import ThemeBuilder
from .widgets import Chart, MetricCard, YamlHighlighter, label
from .about import AboutDialog
from .plots import PlotViewer


class Window(QMainWindow):
    def __init__(self, data_dir):
        super().__init__()
        self.setWindowTitle("ThetaIDE — Research workspace")
        self.resize(1480, 940)
        self.setMinimumSize(1080, 720)
        self.setDockNestingEnabled(True)
        self.store = Store(data_dir)
        self.theme_manager = ThemeManager(Path(data_dir) / ".appearance.json", self)
        saved, errors = self.store.load()
        self.runs = saved or example_runs()
        self.active = None
        self.selected = None
        self.timer = QTimer(self)
        self.timer.setInterval(350)
        self.timer.timeout.connect(self.tick)
        self.make_toolbar()
        self.make_center()
        self.make_explorer()
        self.make_inspector()
        self.make_console()
        self.make_menus()
        self.theme_status = label("", "muted")
        self.statusBar().addWidget(self.theme_status)
        self.theme_manager.changed.connect(self.theme_changed)
        self.theme_changed()
        self.state_label = label("DEMO ENGINE   •   No training process connected  ", "muted")
        self.statusBar().addPermanentWidget(self.state_label)
        self.refresh_runs()
        self.update_config()
        if self.runs:
            self.select_run(self.runs[0])
        self.log("ThetaIDE ready. Demo runs use synthetic metrics; no GPU or dataset is needed.")
        for error in errors:
            self.log(error)
        if self.theme_manager.error:
            self.log(self.theme_manager.error)
        self.resizeDocks([self.explorer_dock, self.inspector_dock], [230, 340], Qt.Orientation.Horizontal)
        self.resizeDocks([self.console_dock], [170], Qt.Orientation.Vertical)
        self.default_layout = self.saveState()

    def button(self, text, callback, primary=False):
        button = QPushButton(text)
        if primary:
            button.setObjectName("primary")
        button.clicked.connect(callback)
        return button

    def make_toolbar(self):
        toolbar = QToolBar("Workspace")
        toolbar.setMovable(False)
        self.addToolBar(toolbar)
        toolbar.addWidget(label("θ  ThetaIDE", "brand"))
        toolbar.addWidget(label("RESEARCH WORKSPACE", "muted"))
        toolbar.addSeparator()
        toolbar.addWidget(self.button("+  New experiment", self.new_experiment))
        self.start_button = self.button("▶  Run demo", self.start_run, True)
        self.start_button.setToolTip("Run 60 synthetic updates in about 21 seconds (F5)")
        toolbar.addWidget(self.start_button)
        self.stop_button = self.button("■  Stop", self.stop_run)
        self.stop_button.setEnabled(False)
        toolbar.addWidget(self.stop_button)
        spacer = QWidget()
        spacer.setObjectName("toolbarSpacer")
        from PyQt6.QtWidgets import QSizePolicy
        spacer.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        toolbar.addWidget(spacer)
        toolbar.addWidget(label("FRONTEND PREVIEW", "badge"))

    def make_center(self):
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)
        monitor = QWidget()
        layout = QVBoxLayout(monitor)
        layout.setContentsMargins(20, 18, 20, 14)
        layout.setSpacing(14)
        layout.addWidget(label("EXPERIMENT / OVERVIEW", "eyebrow"))
        self.run_title = label("Your next experiment", "heading")
        layout.addWidget(self.run_title)
        self.run_caption = label("Configure an experiment, then start the demo.", "muted")
        layout.addWidget(self.run_caption)
        row = QHBoxLayout()
        self.reward_card = MetricCard("EPISODE REWARD", "synthetic evaluation / mean")
        self.loss_card = MetricCard("POLICY LOSS", "synthetic training loss")
        self.steps_card = MetricCard("TIMESTEPS", "configured training budget")
        for card in (self.reward_card, self.loss_card, self.steps_card):
            row.addWidget(card)
        layout.addLayout(row)
        self.progress = QProgressBar()
        self.progress.setTextVisible(False)
        self.progress.setFixedHeight(5)
        layout.addWidget(self.progress)
        self.reward_chart = Chart()
        self.loss_chart = Chart("loss", "Policy loss")
        layout.addWidget(self.reward_chart, 3)
        layout.addWidget(self.loss_chart, 2)
        layout.addWidget(label("●  Selected run     •     Synthetic metrics / frontend demonstration", "muted"))
        self.tabs.addTab(monitor, "Training monitor")

        results = QWidget()
        results_layout = QVBoxLayout(results)
        results_layout.setContentsMargins(18, 18, 18, 18)
        results_layout.addWidget(label("Experiment history", "heading"))
        results_layout.addWidget(label("Select one run to inspect, or two to compare (Ctrl + click).", "muted"))
        self.search = QLineEdit()
        self.search.setPlaceholderText("Filter by experiment name, seed, or status…")
        self.search.textChanged.connect(self.refresh_runs)
        results_layout.addWidget(self.search)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Experiment", "Seed", "Status", "Reward", "Source"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.table.verticalHeader().hide()
        self.table.verticalHeader().setDefaultSectionSize(40)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.itemSelectionChanged.connect(self.table_selected)
        self.table.itemDoubleClicked.connect(lambda _: self.tabs.setCurrentIndex(0))
        results_layout.addWidget(self.table, 1)
        actions = QHBoxLayout()
        actions.addWidget(self.button("Load saved config", self.load_selected_config))
        actions.addWidget(self.button("Compare two runs", self.compare))
        actions.addWidget(self.button("View plot", self.view_selected_plot))
        actions.addStretch()
        results_layout.addLayout(actions)
        self.tabs.addTab(results, "Results browser")

        preview = QWidget()
        preview_layout = QVBoxLayout(preview)
        preview_layout.addWidget(label("Draft config • follows the experiment builder", "muted"))
        self.preview = QPlainTextEdit()
        self.preview.setReadOnly(True)
        self.highlighter = YamlHighlighter(self.preview.document())
        preview_layout.addWidget(self.preview)
        preview_layout.addWidget(self.button("Export YAML…", self.export_config))
        self.tabs.addTab(preview, "config.yaml")
        self.plot_viewer = PlotViewer()
        self.tabs.addTab(self.plot_viewer, "Plot viewer")

    def dock(self, title, name, widget, area):
        dock = QDockWidget(title, self)
        dock.setObjectName(name)
        dock.setWidget(widget)
        self.addDockWidget(area, dock)
        return dock

    def make_explorer(self):
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(10, 12, 10, 8)
        layout.addWidget(label("THETA / LOCAL", "eyebrow"))
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setIndentation(14)
        self.tree.itemClicked.connect(self.tree_selected)
        layout.addWidget(self.tree)
        layout.addWidget(label("●  All demo records stay local", "muted"))
        self.explorer_dock = self.dock("Workspace", "explorer", panel, Qt.DockWidgetArea.LeftDockWidgetArea)

    def make_inspector(self):
        self.inspector_tabs = QTabWidget()
        form_widget = QWidget()
        layout = QVBoxLayout(form_widget)
        layout.setContentsMargins(15, 16, 15, 14)
        layout.setSpacing(12)
        layout.addWidget(label("BUILD AN EXPERIMENT", "eyebrow"))
        layout.addWidget(label("Start with a question.", "heading"))
        description = label("A small, reproducible CartPole experiment.\nTune the parameters and watch a demo run.", "muted")
        description.setWordWrap(True)
        layout.addWidget(description)
        form = QFormLayout()
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        form.setVerticalSpacing(10)
        self.name = QLineEdit(Config().name)
        self.name.setMaxLength(100)
        form.addRow("Experiment name", self.name)
        for title, value in (("Task", "Reinforcement learning"), ("Environment", "CartPole-v1"),
                             ("Method", "PPO · neural policy"), ("Training mode", "Online · demo engine")):
            combo = QComboBox()
            combo.addItem(value)
            combo.setToolTip("This proof of concept supports the CartPole / PPO workflow.")
            form.addRow(title, combo)
        self.seed = QSpinBox()
        self.seed.setRange(0, 2147483647)
        self.seed.setValue(42)
        form.addRow("Random seed", self.seed)
        self.steps = QSpinBox()
        self.steps.setRange(1000, 10000000)
        self.steps.setSingleStep(1000)
        self.steps.setValue(10000)
        form.addRow("Total timesteps", self.steps)
        self.lr = QDoubleSpinBox()
        self.lr.setDecimals(6)
        self.lr.setRange(0.000001, 1)
        self.lr.setSingleStep(0.0001)
        self.lr.setValue(0.0003)
        form.addRow("Learning rate", self.lr)
        self.batch = QComboBox()
        self.batch.addItems(["32", "64", "128", "256"])
        self.batch.setCurrentText("64")
        form.addRow("Batch size", self.batch)
        self.gamma = QDoubleSpinBox()
        self.gamma.setDecimals(3)
        self.gamma.setRange(0, 1)
        self.gamma.setSingleStep(0.01)
        self.gamma.setValue(0.99)
        form.addRow("Discount factor · γ", self.gamma)
        layout.addLayout(form)
        layout.addWidget(label("≈ 21 seconds  /  simulated  /  no GPU", "badge"))
        layout.addWidget(self.button("Preview config  →", lambda: self.tabs.setCurrentIndex(2)))
        layout.addStretch()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(form_widget)
        self.inspector_tabs.addTab(scroll, "Experiment builder")

        notes = QWidget()
        notes_layout = QVBoxLayout(notes)
        self.note_target = label("No run selected", "muted")
        self.note_target.setWordWrap(True)
        notes_layout.addWidget(self.note_target)
        self.notes = QPlainTextEdit()
        self.notes.setPlaceholderText("## Hypothesis\nWhat do you expect to learn?\n\n## Observations\n\n## Next iteration")
        notes_layout.addWidget(self.notes)
        self.note_status = label("Notes are linked to the selected run.", "muted")
        notes_layout.addWidget(self.note_status)
        notes_layout.addWidget(self.button("Save notes", self.save_notes))
        self.inspector_tabs.addTab(notes, "Notes")
        self.inspector_dock = self.dock("Experiment", "inspector", self.inspector_tabs,
                                        Qt.DockWidgetArea.RightDockWidgetArea)
        self.inspector_dock.setMinimumWidth(300)
        self.name.textChanged.connect(self.update_config)
        self.batch.currentTextChanged.connect(self.update_config)
        for field in (self.seed, self.steps, self.lr, self.gamma):
            field.valueChanged.connect(self.update_config)
        self.notes.textChanged.connect(self.notes_changed)

    def make_console(self):
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(0, 0, 0, 0)
        self.console = QPlainTextEdit()
        self.console.setReadOnly(True)
        self.console.setMaximumBlockCount(1000)
        layout.addWidget(self.console)
        self.command = QLineEdit()
        self.command.setPlaceholderText("Demo console › help, status, config, clear (not a system shell)")
        self.command.returnPressed.connect(self.console_command)
        layout.addWidget(self.command)
        self.console_dock = self.dock("Console · demo session", "console", panel, Qt.DockWidgetArea.BottomDockWidgetArea)

    def make_menus(self):
        file_menu = self.menuBar().addMenu("File")
        for title, shortcut, callback in (("New experiment", "Ctrl+N", self.new_experiment),
                                          ("Export draft YAML…", "Ctrl+Shift+S", self.export_config),
                                          ("Save notes", "Ctrl+S", self.save_notes),
                                          ("Quit", "Ctrl+Q", self.close)):
            action = QAction(title, self)
            action.setShortcut(shortcut)
            action.triggered.connect(callback)
            file_menu.addAction(action)
        run_menu = self.menuBar().addMenu("Run")
        for title, shortcut, callback in (("Start demo", "F5", self.start_run), ("Stop demo", "Shift+F5", self.stop_run)):
            action = QAction(title, self)
            action.setShortcut(shortcut)
            action.triggered.connect(callback)
            run_menu.addAction(action)
        view_menu = self.menuBar().addMenu("View")
        self.themes_menu = view_menu.addMenu("Themes")
        self.themes_menu.aboutToShow.connect(self.populate_themes_menu)
        view_menu.addAction("Theme builder…", self.show_theme_builder)
        view_menu.addAction("Plot viewer", lambda: self.tabs.setCurrentWidget(self.plot_viewer))
        for dock in (self.explorer_dock, self.inspector_dock, self.console_dock):
            view_menu.addAction(dock.toggleViewAction())
        view_menu.addAction("Restore default layout", lambda: self.restoreState(self.default_layout))
        help_menu = self.menuBar().addMenu("Help")
        help_menu.addAction("About this prototype", self.show_about)

    def show_about(self):
        dialog = AboutDialog(self)
        dialog.exec()
        dialog.deleteLater()

    def theme_changed(self):
        self.theme_status.setText(f"  ●  Local workspace    /    {self.theme_manager.active['name']}")
        self.highlighter.rehighlight()

    def populate_themes_menu(self):
        self.themes_menu.clear()
        for name, theme in self.theme_manager.themes().items():
            action = self.themes_menu.addAction(name)
            action.setCheckable(True)
            action.setChecked(name == self.theme_manager.active["name"])
            action.triggered.connect(lambda _, palette=theme: self.select_theme(palette))
        self.themes_menu.addSeparator()
        self.themes_menu.addAction("Theme builder…", self.show_theme_builder)

    def select_theme(self, theme):
        try:
            self.theme_manager.commit(theme)
        except (OSError, ValueError) as exc:
            QMessageBox.warning(self, "Could not save theme", str(exc))

    def show_theme_builder(self):
        dialog = ThemeBuilder(self.theme_manager, self)
        dialog.exec()
        dialog.deleteLater()

    def config(self):
        return Config(name=self.name.text().strip() or "untitled_experiment", seed=self.seed.value(),
                      total_timesteps=self.steps.value(), lr=self.lr.value(),
                      batch_size=int(self.batch.currentText()), gamma=self.gamma.value())

    def update_config(self, *_):
        self.preview.setPlainText(self.config().yaml())

    def set_config(self, config):
        self.name.setText(config.name)
        self.seed.setValue(config.seed)
        self.steps.setValue(config.total_timesteps)
        self.lr.setValue(config.lr)
        self.batch.setCurrentText(str(config.batch_size))
        self.gamma.setValue(config.gamma)
        self.update_config()

    def new_experiment(self):
        self.set_config(Config(name="cartpole_ppo_experiment"))
        self.inspector_tabs.setCurrentIndex(0)
        self.inspector_dock.show()
        self.name.setFocus()
        self.name.selectAll()

    def persist(self, run):
        try:
            self.store.save(run)
            return True
        except OSError as exc:
            self.log(f"SAVE FAILED: {exc}")
            self.statusBar().showMessage(f"Could not save run: {exc}", 12000)
            return False

    def start_run(self):
        if self.active:
            self.statusBar().showMessage("A demo is already running. Stop it before starting another.", 4000)
            return
        run = new_run(self.config())
        if not self.persist(run):
            return
        self.active = run
        self.runs.insert(0, run)
        self.select_run(run)
        self.refresh_runs()
        self.tabs.setCurrentIndex(0)
        self.start_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.log(f"[demo] Started {run['config']['name']} · seed {run['config']['seed']} · {run['id']}")
        self.timer.start()

    def tick(self):
        if not self.active:
            return
        run = self.active
        metric = sample(Config(**run["config"]), len(run["metrics"]) + 1)
        run["metrics"].append(metric)
        self.plot_viewer.update_runs(self.runs)
        if self.selected is run:
            self.render_run()
        if len(run["metrics"]) % 10 == 0:
            self.log(f"[demo] step={metric['step']:>6}  reward={metric['reward']:.2f}  loss={metric['loss']:.4f}")
            self.persist(run)
        if len(run["metrics"]) >= 60:
            self.finish("completed")

    def stop_run(self):
        if self.active:
            self.finish("stopped")

    def finish(self, status):
        self.timer.stop()
        run = self.active
        run["status"] = status
        self.persist(run)
        self.log(f"[demo] {status.capitalize()} · {run['id']} · config and metrics saved locally")
        self.active = None
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.refresh_runs()
        self.render_run()

    def select_run(self, run):
        self.selected = run
        self.notes.blockSignals(True)
        self.notes.setPlainText(run["notes"])
        self.notes.blockSignals(False)
        self.note_target.setText(f"Linked to {run['config']['name']}\nRun {run['id']}")
        self.note_status.setText("Notes save automatically as you type.")
        self.render_run()

    def render_run(self):
        run = self.selected
        if not run:
            return
        config = run["config"]
        metrics = run["metrics"]
        self.run_title.setText(config["name"])
        self.run_caption.setText(f"CartPole-v1  /  PPO  /  seed {config['seed']}   •   {run['status'].upper()}   •   SIMULATED")
        last = metrics[-1] if metrics else {"reward": 0, "loss": 0, "step": 0}
        self.reward_card.value.setText(f"{last['reward']:.1f}" if metrics else "—")
        self.loss_card.value.setText(f"{last['loss']:.4f}" if metrics else "—")
        self.steps_card.value.setText(f"{last['step']:,}")
        self.progress.setValue(round(100 * last["step"] / config["total_timesteps"]))
        self.reward_chart.set_series([(config["name"], metrics, "#b8bb26")])
        self.loss_chart.set_series([(config["name"], metrics, "#83a598")])

    def refresh_runs(self, *_):
        self.plot_viewer.update_runs(self.runs)
        query = self.search.text().lower()
        self.table.blockSignals(True)
        self.table.setRowCount(0)
        self.tree.clear()
        project = QTreeWidgetItem(self.tree, ["▾  theta-workspace"])
        draft = QTreeWidgetItem(project, ["◇  config.yaml"])
        draft.setData(0, Qt.ItemDataRole.UserRole, "draft")
        folder = QTreeWidgetItem(project, [f"▾  Experiments ({len(self.runs)})"])
        for run in self.runs:
            config = run["config"]
            item = QTreeWidgetItem(folder, [config["name"]])
            item.setData(0, Qt.ItemDataRole.UserRole, run["id"])
            item.setToolTip(0, f"{run['status']} · seed {config['seed']} · synthetic data")
            if query not in f"{config['name']} {config['seed']} {run['status']}".lower():
                continue
            row = self.table.rowCount()
            self.table.insertRow(row)
            reward = f"{run['metrics'][-1]['reward']:.1f}" if run["metrics"] else "—"
            for col, value in enumerate((config["name"], str(config["seed"]), run["status"], reward, "Simulated")):
                cell = QTableWidgetItem(value)
                cell.setData(Qt.ItemDataRole.UserRole, run["id"])
                self.table.setItem(row, col, cell)
        catalog = QTreeWidgetItem(project, ["◇  Backend reference"])
        for title in ("PPO / dnn", "CartPole-v1", "Hydra config groups"):
            QTreeWidgetItem(catalog, [title]).setToolTip(0, "Reference only; backend is not loaded")
        self.tree.expandAll()
        self.table.blockSignals(False)

    def by_id(self, run_id):
        return next((run for run in self.runs if run["id"] == run_id), None)

    def view_selected_plot(self):
        if self.selected:
            self.plot_viewer.show_run(self.selected["id"])
        self.tabs.setCurrentWidget(self.plot_viewer)

    def tree_selected(self, item, _):
        run_id = item.data(0, Qt.ItemDataRole.UserRole)
        if run_id == "draft":
            self.tabs.setCurrentIndex(2)
        elif run := self.by_id(run_id):
            self.select_run(run)
            self.tabs.setCurrentIndex(0)

    def table_selected(self):
        rows = self.table.selectionModel().selectedRows()
        if len(rows) == 1:
            run = self.by_id(self.table.item(rows[0].row(), 0).data(Qt.ItemDataRole.UserRole))
            self.select_run(run)

    def notes_changed(self):
        if self.selected:
            self.selected["notes"] = self.notes.toPlainText()
            ok = self.persist(self.selected)
            self.note_status.setText("Saved locally · linked to this run" if ok else "Save failed · see console")

    def save_notes(self):
        self.notes_changed()

    def load_selected_config(self):
        rows = self.table.selectionModel().selectedRows()
        if len(rows) != 1:
            self.statusBar().showMessage("Select exactly one run to load its saved config.", 5000)
            return
        run = self.by_id(self.table.item(rows[0].row(), 0).data(Qt.ItemDataRole.UserRole))
        self.set_config(Config(**run["config"]))
        self.inspector_tabs.setCurrentIndex(0)
        self.inspector_dock.show()
        self.tabs.setCurrentIndex(2)
        self.log(f"Loaded exact configuration from {run['id']}. Run demo to create a new record.")

    def compare(self):
        rows = self.table.selectionModel().selectedRows()
        if len(rows) != 2:
            self.statusBar().showMessage("Select exactly two runs with Ctrl + click to compare.", 5000)
            return
        runs = [self.by_id(self.table.item(index.row(), 0).data(Qt.ItemDataRole.UserRole)) for index in rows]
        dialog = QDialog(self)
        dialog.setWindowTitle("Compare experiments · simulated results")
        dialog.resize(820, 660)
        layout = QVBoxLayout(dialog)
        layout.addWidget(label("Two runs. One question.", "heading"))
        chart = Chart()
        chart.set_series([(run["config"]["name"], run["metrics"], color)
                          for run, color in zip(runs, ("#b8bb26", "#83a598"))])
        layout.addWidget(chart, 1)
        for run, color in zip(runs, ("#b8bb26", "#83a598")):
            legend = label(f"●  {run['config']['name']} · seed {run['config']['seed']} · {run['id']}")
            legend.setStyleSheet(f"color: {theme_color(color)}")
            layout.addWidget(legend)
        diff = QTableWidget(len(asdict(Config())), 3)
        diff.setHorizontalHeaderLabels(["Parameter", "Run A", "Run B"])
        diff.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        diff.verticalHeader().hide()
        diff.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        for row, key in enumerate(asdict(Config())):
            for col, value in enumerate((key, runs[0]["config"][key], runs[1]["config"][key])):
                cell = QTableWidgetItem(str(value))
                if runs[0]["config"][key] != runs[1]["config"][key]:
                    from PyQt6.QtGui import QColor
                    cell.setForeground(QColor(theme_color("accent")))
                diff.setItem(row, col, cell)
        layout.addWidget(diff, 1)
        layout.addWidget(label("Changed parameters are highlighted. These curves are synthetic.", "muted"))
        dialog.exec()

    def export_config(self):
        path, _ = QFileDialog.getSaveFileName(self, "Export configuration", "experiment.yaml", "YAML (*.yaml)")
        if path:
            try:
                Path(path).write_text(self.config().yaml(), encoding="utf-8")
                self.log(f"Exported draft configuration to {path}")
            except OSError as exc:
                QMessageBox.warning(self, "Export failed", str(exc))

    def log(self, message):
        self.console.appendPlainText(message)

    def console_command(self):
        command = self.command.text().strip()
        self.command.clear()
        self.log(f"theta › {command}")
        if command == "clear":
            self.console.clear()
        elif command == "help":
            self.log("help    Show commands\nstatus  Show demo engine state\nconfig  Show draft config\nclear   Clear output\nThis console does not execute Python or shell commands.")
        elif command == "status":
            self.log(f"Demo engine: {'running' if self.active else 'idle'} · {len(self.runs)} records")
        elif command == "config":
            self.log(self.config().yaml())
        elif command:
            self.log("Unknown demo command. Type help for available commands.")

    def closeEvent(self, event):
        self.stop_run()
        self.save_notes()
        event.accept()


def main():
    parser = argparse.ArgumentParser(description="ThetaIDE PyQt frontend proof of concept")
    parser.add_argument("--data-dir", type=Path, default=Path(__file__).resolve().parent.parent / ".thetaide" / "runs")
    args = parser.parse_args()
    app = QApplication(sys.argv[:1])
    app.setStyle("Fusion")
    app.setFont(QFont("Segoe UI", 10))
    app.setStyleSheet(STYLE)
    try:
        window = Window(args.data_dir)
    except OSError as exc:
        QMessageBox.critical(None, "Workspace unavailable", f"Could not open local run storage:\n{exc}")
        return 1
    window.show()
    return app.exec()
