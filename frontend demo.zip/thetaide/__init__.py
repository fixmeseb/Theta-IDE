"""ThetaIDE desktop frontend proof of concept."""
