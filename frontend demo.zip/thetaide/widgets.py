import re
from PyQt6.QtCore import Qt, QRectF
from PyQt6.QtGui import QColor, QPainter, QPainterPath, QPen, QFont, QSyntaxHighlighter, QTextCharFormat
from PyQt6.QtWidgets import QWidget, QLabel, QVBoxLayout, QFrame
from .theme import theme_color


def label(text, kind=None):
    result = QLabel(text)
    if kind:
        result.setObjectName(kind)
    return result


class MetricCard(QFrame):
    def __init__(self, title, subtitle):
        super().__init__()
        self.setObjectName("card")
        layout = QVBoxLayout(self)
        layout.addWidget(label(title, "muted"))
        self.value = label("—", "value")
        layout.addWidget(self.value)
        layout.addWidget(label(subtitle, "muted"))


class YamlHighlighter(QSyntaxHighlighter):
    def highlightBlock(self, text):
        for pattern, color in ((r'^\s*[\w_]+(?=:)', '#83a598'),
                               (r'\b\d+(?:\.\d+)?\b', '#d3869b'),
                               (r'"[^"\n]*"', '#b8bb26'), (r'#.*$', '#928374')):
            fmt = QTextCharFormat()
            fmt.setForeground(QColor(theme_color(color)))
            for match in re.finditer(pattern, text):
                self.setFormat(match.start(), len(match.group()), fmt)


class Chart(QWidget):
    """Small dependency-free plot; drawing only, no synthetic data hidden here."""
    def __init__(self, metric="reward", title="Episode reward"):
        super().__init__()
        self.metric, self.title = metric, title
        self.series = []
        self.setMinimumHeight(185)
        self.setMinimumWidth(240)

    def set_series(self, series):
        self.series = series
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), QColor(theme_color("panel")))
        painter.setFont(QFont("Segoe UI", 10))
        painter.setPen(QColor(theme_color("text")))
        painter.drawText(16, 24, self.title)
        area = QRectF(48, 45, self.width() - 70, self.height() - 80)
        points = [m for _, metrics, _ in self.series for m in metrics]
        xmax = max([m["step"] for m in points] or [10000])
        ymax = 500 if self.metric == "reward" else max([m[self.metric] for m in points] or [1]) * 1.1
        painter.setFont(QFont("Segoe UI", 8))
        for i in range(5):
            y = area.bottom() - area.height() * i / 4
            painter.setPen(QColor(theme_color("raised")))
            painter.drawLine(int(area.left()), int(y), int(area.right()), int(y))
            painter.setPen(QColor(theme_color("muted")))
            painter.drawText(QRectF(0, y - 8, 40, 16), Qt.AlignmentFlag.AlignRight,
                             f"{ymax * i / 4:.0f}" if self.metric == "reward" else f"{ymax * i / 4:.2f}")
        for i in range(5):
            x = area.left() + area.width() * i / 4
            painter.drawText(QRectF(x - 25, area.bottom() + 8, 50, 18), Qt.AlignmentFlag.AlignCenter,
                             f"{xmax * i / 4000:g}k")
        for _, metrics, color in self.series:
            if not metrics:
                continue
            path = QPainterPath()
            for i, m in enumerate(metrics):
                x = area.left() + area.width() * m["step"] / max(1, xmax)
                y = area.bottom() - area.height() * m[self.metric] / max(0.001, ymax)
                if i == 0:
                    path.moveTo(x, y)
                else:
                    path.lineTo(x, y)
            painter.setPen(QPen(QColor(theme_color(color)), 2))
            painter.drawPath(path)
        if not points:
            painter.setPen(QColor(theme_color("muted")))
            painter.drawText(area, Qt.AlignmentFlag.AlignCenter, "Start a demo run to see live metrics")
